// const express = require('express');
// import { createServer } from "http";
// import { Server } from "socket.io";
// var app = express();
// const server = http.createServer(app);
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");

const port = process.env.PORT || 7500;

const io = new Server(server, {
  cors: {
    origin: 'http://localhost:3000',
    methods: ['POST', 'GET'],
    credentials: true
  },
  allowEIO3: true,
  secure: true
});

// handle incoming connections from clients
io.on('connection', function(socket) {
    // once a client has connected, we expect to get a ping from them saying what room they want to join
    socket.on('room', function(room) {
      io.in(room).emit('message', 'Someone joined the room');
      console.log("Joined session:", room)
      socket.join(room);
    });
    socket.on('disconnect',(reason)=>{
      console.log(reason)
    })
});


server.listen(port);


// const cors = require('cors')
// require('dotenv').config() // Environment variables stored in .env file

// const port = process.env.PORT || 7500;

// const app = express();


// app.use(express.json());

// const webSockets = require('../backend/services/webSockets');
// const io = temp.setUpWebSockets(app, port)
// // require('./version/v1')(app, db, auth, passport, io);

// const http = require('http');
// const socketIo = require("socket.io");

// exports.setUpWebSockets = (app, port) => {

//   console.log("Socket module connected")
//   // TODO: Move Web Socket to different server.
//   // Socket.io
//   const server = http.createServer(app);
//   // const io = socketIo(server);
//   const io = socketIo(server, {
//     cors: {
//       origin: 'http://localhost:3000'
//     }
//   }); //in case server and client run on different urls

//   // handle incoming connections from clients
//   io.on('connection', function(socket) {
//       // once a client has connected, we expect to get a ping from them saying what room they want to join
//       socket.on('room', function(room) {
//         io.in(room).emit('message', 'Someone joined the room');
//         console.log("Joined session:", room)
//         socket.join(room);
//       });
//       socket.on('disconnect',(reason)=>{
//         console.log(reason)
//       })
//   });

//   server.listen(port)

//   return io;

// }

// // app.listen(port, () => {
// //   console.log(`Listening on http://localhost:${port}/`)
// // })
